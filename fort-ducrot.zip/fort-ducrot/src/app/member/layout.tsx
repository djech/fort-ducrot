import React from 'react'

const MemberLayout = () => {
  return (
    <div>Member section</div>
  )
}

export default MemberLayout