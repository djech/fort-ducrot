import React from 'react'

const MemberProfile = () => {
  return (
    <div>MemberProfile
    
    </div>
  )
}

export default MemberProfile