import React from 'react'
import styles from './page.module.css'

const Contact = () => {
  return (
    <div className={styles.contact}>Contact</div>
  )
}

export default Contact